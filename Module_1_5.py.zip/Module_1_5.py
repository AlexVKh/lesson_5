immutable_var = 1, 'two', 3.0, False, [5,6]
print('Immutable tuple:', immutable_var)
#immutable_var[1] = 'not two'
#print(immutable_var[1])
#immutable_var[4][0] = 'five'
#print(immutable_var[4])
#print('Кортеж относится к неизменяемым типам данных, но внутри может содержать изменяемые типы')
mutable_list = [1, 2, 3, 'four']
mutable_list = ['one', 2.0, 'three', 4]
print('Mutable list:',mutable_list)
